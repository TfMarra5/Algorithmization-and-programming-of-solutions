package compression;

public class NucleotideCompressor {

    // Task 1 – Compression
    public static byte[] compress(String nucleotides) {
        if (nucleotides == null) {
            return new byte[] { 0 };
        }

        int length = nucleotides.length();
        // primeiro byte guarda o número de nucleotídeos
        int dataBytes = (length + 3) / 4;  // 4 nucleotídeos por byte
        byte[] res = new byte[1 + dataBytes];
        res[0] = (byte) length;

        int byteIndex = 1;
        int bitPos = 6;  // começamos nos bits mais significativos
        byte current = 0;

        for (int i = 0; i < length; i++) {
            char c = nucleotides.charAt(i);
            int val;
            switch (c) {
                case 'A': val = 0b00; break;
                case 'C': val = 0b01; break;
                case 'G': val = 0b10; break;
                case 'T': val = 0b11; break;
                default:  val = 0b00; break; // fallback
            }

            current |= (byte) (val << bitPos);

            if (bitPos == 0) {
                res[byteIndex++] = current;
                current = 0;
                bitPos = 6;
            } else {
                bitPos -= 2;
            }
        }

        // salva último byte, se tiver sobrado algo
        if (bitPos != 6) {
            res[byteIndex] = current;
        }

        return res;
    }

    // Task 2 – Decompression
    public static String decompress(byte[] nucleotides) {
        if (nucleotides == null || nucleotides.length == 0) {
            return "";
        }

        int length = nucleotides[0] & 0xFF; // número de nucleotídeos
        StringBuilder sb = new StringBuilder(length);

        for (int i = 0; i < length; i++) {
            int byteIndex = 1 + (i / 4);
            int shift = 6 - 2 * (i % 4);

            int bits = (nucleotides[byteIndex] >> shift) & 0b11;

            char c;
            switch (bits) {
                case 0b00: c = 'A'; break;
                case 0b01: c = 'C'; break;
                case 0b10: c = 'G'; break;
                case 0b11: c = 'T'; break;
                default:   c = 'A'; break;
            }

            sb.append(c);
        }

        return sb.toString();
    }

    // helper para imprimir bits (usado no Main)
    public static String toBits(byte b) {
        StringBuilder sb = new StringBuilder(9);
        int mask = 0x80;
        for (int i = 0; i < 8; i++) {
            if ((b & mask) != 0) {
                sb.append('1');
            } else {
                sb.append('0');
            }
            mask >>>= 1;
            if (i == 3) {
                sb.append(' ');
            }
        }
        return sb.toString();
    }

}
