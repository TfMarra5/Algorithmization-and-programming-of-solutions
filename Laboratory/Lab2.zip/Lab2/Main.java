import java.util.Scanner;
import java.util.List;

import messages.*;

import parsing.BalancedBrackets;
import parsing.Parser;
import parsing.TokenCompare;
import parsing.token.*;
import parsing.tokenizer.JavaTokenizer;

import compression.NucleotideCompressor;

import parsing.codeexamples.*;

public class Main {

    private static Scanner sc;

    public static void main(String[] args) {
        sc = new Scanner(System.in);

        while (true) {
            System.out.print("block> ");
            String line = sc.nextLine().trim();

            switch (line) {
                case "1": {
                    messagesTask();
                    break;
                }
                case "2": {
                    parsingTask();
                    break;
                }
                case "3": {
                    compressionTask();
                    break;
                }
                case "q":
                case "quit":
                case "exit":
                case "":
                    return;
                default:
                    System.out.println("Unknown block. Use 1, 2, 3 or 'q' to quit.");
            }
        }
    }

    // =======================
    // Block 1 – Message Encoding
    // =======================

    public static void messagesTask() {
        System.out.print("message: ");
        String message = sc.nextLine();

        Encoder joinEncoder = new JoinEncoder(
            new SubstitutionEncoder("qwertyuiopasdfghjklzxcvbnm"),
            new CaesarEncoder(5),
            new XOREncoder("I shall not copy")
        );

        String encoded = joinEncoder.encode(message);
        System.out.println("encoded:");
        System.out.println(encoded);

        String decoded = joinEncoder.decode(encoded);
        System.out.println("decoded:");
        System.out.println(decoded);
    }

    // =======================
    // Block 2 – Parsing
    // =======================

    public static void parsingTask() {
        System.out.print("task> ");
        String line = sc.nextLine().trim();

        JavaTokenizer tokenizer = new JavaTokenizer();

        switch (line) {
            case "1": {
                // Task 1 – Removing invisible tokens and comments
                System.out.println("original text:");
                System.out.println(CommentsExamples.example1);

                List<Token> tokens = tokenizer.tokenize(CommentsExamples.example1);

                System.out.println("\ncleaned tokens:");
                for (Token t : tokens) {
                    System.out.println(t);
                }
                break;
            }
            case "2": {
                // Task 2 – Bracket Token (mostrar tokens com brackets)
                String expr = BracketsExamples.balanced1;
                System.out.println("expression:");
                System.out.println(expr);

                List<Token> tokens = tokenizer.tokenize(expr);

                System.out.println("\ntokens:");
                for (Token t : tokens) {
                    System.out.println(t);
                }
                break;
            }
            case "3": {
                // Task 3 – Balanced brackets
                String[] exprs = {
                    BracketsExamples.balanced1,
                    BracketsExamples.balanced2,
                    BracketsExamples.balanced3,
                    BracketsExamples.unbalanced1,
                    BracketsExamples.unbalanced2,
                    BracketsExamples.unbalanced3,
                    BracketsExamples.unbalanced4
                };

                for (String expr : exprs) {
                    List<Token> tokens = tokenizer.tokenize(expr);
                    boolean balanced = BalancedBrackets.areBracketsBalanced(tokens);
                    System.out.printf("%-40s -> %s%n",
                        expr,
                        balanced ? "balanced" : "NOT balanced");
                }
                break;
            }
            case "4": {
                // Task 4 – Syntax tree
                String code = CodeExamples.example1;
                System.out.println("code:");
                System.out.println(code);

                List<Token> tokens = tokenizer.tokenize(code);

                System.out.println("\nsyntax tree:");
                System.out.println(Parser.syntaxTree(tokens));
                break;
            }
            case "5": {
                // Task 5 – Longest Common Subsequence
                String code1 = CodeExamples.example1;
                String code2 = CodeExamples.example2;

                List<Token> tokens1 = tokenizer.tokenize(code1);
                List<Token> tokens2 = tokenizer.tokenize(code2);

                int len = TokenCompare.lcs(tokens1, tokens2);

                System.out.println("LCS length: " + len);
                break;
            }
            default:
                System.out.println("Unknown parsing task. Use 1-5.");
        }
    }

    // =======================
    // Block 3 – Data Compression
    // =======================

    public static void compressionTask() {
        String nucleotides = "AATCCGCTAG";
        System.out.println("nucleotides:");
        System.out.println(nucleotides);

        byte[] comp = NucleotideCompressor.compress(nucleotides);

        System.out.println("\ncompressed nucleotides in decimal:");
        for (int i = 0; i < comp.length; i++) {
            System.out.print(comp[i] + " ");
        }

        System.out.println("\n\ncompressed nucleotides in binary:");
        for (int i = 0; i < comp.length; i++) {
            System.out.print(NucleotideCompressor.toBits(comp[i]));
        }

        String decomp = NucleotideCompressor.decompress(comp);
        System.out.println("\n\ndecompressed nucleotides:");
        System.out.println(decomp);
    }

}
