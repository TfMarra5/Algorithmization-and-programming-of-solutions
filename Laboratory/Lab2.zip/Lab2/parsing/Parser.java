package parsing;

import java.util.List;

import parsing.token.*;
import parsing.token.Bracket;

public class Parser {

    public static String syntaxTree(List<Token> tokens) {
        StringBuilder sb = new StringBuilder();
        int depth = 0;

        for (Token t : tokens) {
            Bracket b = toBracket(t);

            // fecha nível antes de imprimir bracket de fechamento
            if (b != null && b.isClosed()) {
                depth = Math.max(0, depth - 1);
            }

            // indentação: 2 espaços por nível
            for (int i = 0; i < depth; i++) {
                sb.append("  ");
            }
            sb.append(t.toString()).append(System.lineSeparator());

            // abre nível depois de imprimir bracket de abertura
            if (b != null && b.isOpen()) {
                depth++;
            }
        }

        return sb.toString();
    }

    private static Bracket toBracket(Token t) {
        if (t instanceof Bracket) {
            return (Bracket) t;
        }
        if (t instanceof Symbol) {
            String s = t.getString();
            if ("(){}[]".contains(s)) {
                return new Bracket(s);
            }
        }
        return null;
    }

}
