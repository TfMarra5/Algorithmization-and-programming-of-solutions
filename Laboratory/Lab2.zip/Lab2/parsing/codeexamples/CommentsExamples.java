package parsing.codeexamples;

public class CommentsExamples {
    
    public static final String example1 = """
Hello, World! // say hello
Java has for and while loops. // java has loops
Java also has if and switch statements. // java has conditions
""";

}
