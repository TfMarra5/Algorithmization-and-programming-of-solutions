package parsing.token;

public abstract class Token {

    protected String str;

    protected Token(String str) {
        this.str = str;
    }
    
    public abstract String toString();

    public String getString() {
        return str;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Token other = (Token) obj;
        return str != null ? str.equals(other.str) : other.str == null;
    }

    @Override
    public int hashCode() {
        return str != null ? str.hashCode() : 0;
    }
}
