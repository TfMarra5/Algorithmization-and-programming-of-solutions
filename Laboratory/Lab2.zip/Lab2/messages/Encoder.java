package messages;

public abstract class Encoder {
    
    public abstract String encode(String message);

    public abstract String decode(String message);

}
